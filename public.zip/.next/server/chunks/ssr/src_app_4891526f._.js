module.exports=[97656,a=>{a.v("/_next/static/media/icon.1aa74213.png")},90653,a=>{"use strict";a.s(["default",()=>b]);let b={src:a.i(97656).default,width:547,height:512}}];

//# sourceMappingURL=src_app_4891526f._.js.map