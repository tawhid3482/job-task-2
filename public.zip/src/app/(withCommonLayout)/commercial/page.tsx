import React from "react";
import Residentials from "../residential/page";

const Commercial = () => {
  return <div>
    <Residentials />
  </div>;
};

export default Commercial;
