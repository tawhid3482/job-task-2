globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/d74da9c0dc1782bc.js",
      "static/chunks/turbopack-e7b083447f1593c0.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/d74da9c0dc1782bc.js",
      "static/chunks/turbopack-44760ffecee78c12.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/f2441e65e5af3638.js",
    "static/chunks/522518d740397639.js",
    "static/chunks/2008ffcf9e5b170c.js",
    "static/chunks/737148e6b6e52fe4.js",
    "static/chunks/8082ab48faca5ea1.js",
    "static/chunks/turbopack-394d4090e2271970.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];