globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/27fc1e65c9015dfe.js",
      "static/chunks/turbopack-0af46446af824597.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/27fc1e65c9015dfe.js",
      "static/chunks/turbopack-a949397ee6fbf044.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/3eba6931cad880e3.js",
    "static/chunks/522518d740397639.js",
    "static/chunks/2008ffcf9e5b170c.js",
    "static/chunks/737148e6b6e52fe4.js",
    "static/chunks/8082ab48faca5ea1.js",
    "static/chunks/turbopack-4d2292df9c8b905b.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];