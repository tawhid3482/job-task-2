var R=require("../../chunks/[turbopack]_runtime.js")("server/app/icon.png/route.js")
R.c("server/chunks/[root-of-the-server]__9fc28dcf._.js")
R.c("server/chunks/[root-of-the-server]__a0a6d59c._.js")
R.m(37083)
R.m(58338)
module.exports=R.m(58338).exports
