__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/27fc1e65c9015dfe.js",
  "static/chunks/turbopack-a949397ee6fbf044.js"
])
