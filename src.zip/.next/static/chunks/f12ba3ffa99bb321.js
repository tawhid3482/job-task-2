__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/27fc1e65c9015dfe.js",
  "static/chunks/turbopack-0af46446af824597.js"
])
